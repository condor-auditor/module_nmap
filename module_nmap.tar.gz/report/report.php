<?php 
/* 
#modulo sslstrip es una herramienta para CONDOR.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
require_once ('../../../dompdf/autoload.inc.php');
include_once("../__init__.php");

ob_start();
set_time_limit("120");
ini_set("memory_limit","50M");

use Dompdf\Dompdf;

 // instantiate and use the dompdf class
$dompdf = new Dompdf();

mt_srand(time());
$nombre = uniqid(mt_rand());
$nombre = $nombre.".pdf";
$ruta = $path_module_nmap."/pdf/".$nombre;
exec_condor("chmod -R 777 $path_module_nmap/pdf/");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$action = strip_tags(trim(filter_input(INPUT_POST,'action', FILTER_SANITIZE_STRING)));
	$documento = strip_tags(trim(filter_input(INPUT_POST,'documento', FILTER_SANITIZE_STRING)));

	if ($action != "") {
		if ($action == "report_list_connect") {

			$target = "wlo1";

			$list_total = array();
			$total = array();

			$wget_file="/tmp/mac.vendor";

			$target = preg_replace('[\s+]',"", $target);
			$broadcast = exec_condor("ifconfig $target | grep -oiE '([0-9]{1,3}\.){3}[0-9]{1,3}{2}'");

			exec("/sbin/iw dev $target station dump |grep Stat | cut -f 2 -s -d' '", $stations);

			for ($i=0; $i < count($stations); $i++) {
				$output[] = str_replace("Station", "", $stations[$i]);
			}

			exec("ping -b -q -c 2 -s 1472 $broadcast > /dev/null 2>&1");


			foreach ($output as $mac) {
				$mac= $mac;
				exec("wget http://api.macvendors.com/$mac -O $wget_file > /dev/null 2>&1");
				$vendor = shell_exec("cat $wget_file");
				exec("rm $wget_file");
				$ip = shell_exec("arp -a | grep $mac | cut -f 2 -d' '");

				$retval[] =  $vendor."-".$mac."-".$ip;

			}


			$paste = '<!DOCTYPE html>
			<html lang="es">

			<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width,initial-scale=1,maximun-scale=1,user-scalable=no">
				<title></title>
				<link href="" rel="shortcut icon">
				<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
				<link type="text/css" rel="stylesheet" href="../../../css/materialize.css">
				<link type="text/css" rel="stylesheet" href="../../../css/estilos.css">
				<link rel="stylesheet" type="text/css" href="../../../css/animate.css">
			</head>
			<body>

				<div class="row">
					<!-- CAJA PARA dispositivos station-->
					<div class="col l12 s12 m12 card grey lighten-3">
						<div class="card-content blue card-title"><h5 class="center-align white-text margen_text">REPORTES CONDOR</h5><p class="white-text center-align">Fecha: '.date('Y-m-d').' Hora:'.date('H:m:s').'</p><br></div>
						<div class="card-content blue darken-3 card-title"><p class="right-align white-text ">Una forma facil de descubrir cosas</p></div>

						<div class="card">
							<div class="card-content pink darken-4 card-title"><h5 class=" center-align  white-text ">NMAP | v'.$module_version.'</h5></div>
							<div class="row">
								<div class="col l12 s12 m12">
									<table class="highlight bordered centered">
										<thead>
											<tr>
												<th data-field="model" class="black-text">NAME</th>
												<th data-field="cores" class="black-text">MACCADRESS</th>
												<th data-field="cores" class="black-text">IP</th>
												<th data-field="cores" class="black-text">TARGET</th>
												<th data-field="cores" class="black-text">BROADCAST</th>
											</tr>
										</thead>
										<tbody>';
											foreach ($retval as $value) {
												$a = explode("-", $value);
												$filter_1 =array_filter($a, "strlen");

												$list_clean = array_values($filter_1);
												$paste1.='
												<tr>
													<td class=" deep-purple-text">'.$list_clean[0].'</td>
													<td class=" deep-purple-text">'.$list_clean[1].'</td>
													<td class=" deep-purple-text">'.$list_clean[2].'</td>
													<td class=" deep-purple-text">'.$target.'</td>
													<td class=" deep-purple-text">'.$broadcast.'</td>
												</tr>';
											} $paste2.= '
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</body>
			';

			$past_fin = $paste . $paste1 . $paste2;

					// reference the Dompdf namespace

			$dompdf->loadHtml($past_fin);

					// (Optional) Setup the paper size and orientation
			$dompdf->setPaper('legal', 'landscape');

					// Render the HTML as PDF
			$dompdf->render();

					// Output the generated PDF to Browser
			$pdf = $dompdf->output();

			file_put_contents($path_module_nmap."/pdf/".$nombre, $pdf);
			die($path_base."/pdf/".$nombre);
		}elseif ($action == "list_document") {
				exec("ls $path_module_nmap"."/pdf/",$cant_report);
			    $cont = 1;
			    foreach ($cant_report as $line) {
			    	$content[] = array(
			    		'name_pdf' => $line,
			    		'cant' => $cont
			    	);
			    	$cont++;
				}
			echo json_encode($content);
		}elseif ($action == "delete_document") {
			$ruta_document = $path_module_nmap."/pdf/".$documento;
			unlink($ruta_document);

			if (file_exists($ruta_document)) {
				echo "no";
			}else{
				exec("ls $path_module_nmap"."/pdf/",$cant_report);
			    $cont = 1;
			    foreach ($cant_report as $line) {
			    	$content[] = array(
			    		'name_pdf' => $line,
			    		'cant' => $cont
			    	);
			    	$cont++;
				}
			}

			echo json_encode($content);
			}elseif ($action == "list_compress") {
				exec("ls $path_log_directory_compress_nmap",$cant_report);

			    $cont = 1;
			    foreach ($cant_report as $line) {
			    	$content[] = array(
			    		'name_compress' => $line,
			    		'cant' => $cont
			    	);
			    	$cont++;
				}
			echo json_encode($content);
		}elseif ($action == "delete_compress") {
			$ruta_document = $path_log_directory_compress_nmap.$documento;
			exec_condor("rm -rf $ruta_document");

			if (file_exists($ruta_document)) {
				echo "no";
			}else{
				exec("ls $path_log_directory_compress_nmap",$cant_report);

			    $cont = 1;
			    foreach ($cant_report as $line) {
			    	$content[] = array(
			    		'name_compress' => $line,
			    		'cant' => $cont
			    	);
			    	$cont++;
				}
			}

			echo json_encode($content);
		}elseif ($action == "report_all_log") {
				$services_running = file($path_log_nmap);


			$paste = '<!DOCTYPE html>
			<html lang="es">

			<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width,initial-scale=1,maximun-scale=1,user-scalable=no">
				<title></title>
				<link href="" rel="shortcut icon">
				<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
				<link type="text/css" rel="stylesheet" href="../../../css/materialize.css">
				<link type="text/css" rel="stylesheet" href="../../../css/estilos.css">
				<link rel="stylesheet" type="text/css" href="../../../css/animate.css">
			</head>
			<body>

				<div class="row">
					<!-- CAJA PARA dispositivos station-->
					<div class="col l12 s12 m12 card grey lighten-3">
						<div class="card-content blue card-title"><h5 class="center-align white-text margen_text">REPORTES CONDOR</h5><p class="white-text center-align">Fecha: '.date('Y-m-d').' Hora:'.date('H:m:s').'</p><br></div>
						<div class="card-content blue darken-3 card-title"><p class="right-align white-text ">Una forma facil de descubrir cosas</p></div>

						<div class="card">
							<div class="card-content pink darken-4 card-title"><h5 class=" center-align  white-text ">NMAP | v'.$module_version.'</h5></div>
							<div class="row">
								<div id="logs" class="col s12">
									<div class="card">
										<div class="row">
											<div class="col l12 s12 m12">
												<div id="loading_logs_read">
													<div class="indeterminate"></div>
												</div>
												<div class="col l12 s12 m12">
													<div class="black" id="logs_content" style="word-wrap: break-word">';
													    foreach($services_running as $service){
															$paste1.='
            													<p><h6 class="center-align green-text">'.$service.'</h6></p>
															'; 
														    }$paste2.='
													</div>
												</div>
											</div> 
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</body>
			';

			$past_fin = $paste . $paste1 . $paste2;

					// reference the Dompdf namespace

			$dompdf->loadHtml($past_fin);

					// (Optional) Setup the paper size and orientation
			$dompdf->setPaper('legal', 'landscape');

					// Render the HTML as PDF
			$dompdf->render();

					// Output the generated PDF to Browser
			$pdf = $dompdf->output();

			file_put_contents($path_module_nmap."/pdf/".$nombre, $pdf);
			die($path_base."/pdf/".$nombre);
				
			}
	}
}else{
	die(false);
}
?>