<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

$module_name="module_nmap";
$path_bin_nmap = "nmap";
$module_version = "1.0";
$module_version_software  ="https://raw.githubusercontent.com/condor-auditor/".$module_name."/master/version";
$path_module_dowload = "https://github.com/condor-auditor/".$module_name.".git";
$module_author = "@sasaga92";
$module_contact = "ssanchezga@ufpso.edu.co";
$path_module_nmap = "/usr/share/lighttpd/condor/www/modules/".$module_name;
$path_log_directory_nmap = $path_module_nmap."/logs/";
$path_log_directory_compress_nmap = $path_log_directory_nmap."compress/";
$path_log_nmap = $path_log_directory_nmap."nmap.log";
$path_log_list_connect = $path_module_nmap."/logs/list_connect.txt";
$path_log_nmap_command_pid = $path_module_nmap."/logs/command_pid.log";
$path_log_service_running = "/usr/share/lighttpd/condor/logs/SERVICES_RUNNING";
$path_ip_forward = "/proc/sys/net/ipv4/ip_forward";
$path_base = BASE."/modules/".$module_name;
$module_description = "Nmap es un programa de código abierto que sirve para efectuar rastreo de puertos escrito originalmente por Gordon Lyon (más conocido por su alias Fyodor Vaskovich) y cuyo desarrollo se encuentra hoy a cargo de una comunidad. Fue creado originalmente para Linux aunque actualmente es multiplataforma. ";
$path_binary_module = "module_nmap.tar.gz.gpg";
$name_compress_module = "module_nmap.tar.gz";
$link_pag_oficial_nmap = "https://nmap.org/";
$link_tutorial_nmap = "https://www.youtube.com/embed/UL0qwcUsYDM";
$link_dowload_project = "https://github.com/nmap/nmap";
?>
