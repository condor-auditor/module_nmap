<?php
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

include_once("../../../system/login_check.php");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	include_once("../../../tools/execute/exec.php");
	include_once("../__init__.php");

 	$target = strip_tags(trim(filter_input(INPUT_POST,'target', FILTER_SANITIZE_STRING)));

    $list_total = array();
    $total = array();

    $wget_file="/tmp/mac.vendor";

    $target = preg_replace('[\s+]',"", $target);
    $broadcast = exec_condor("ifconfig $target | grep -oiE '([0-9]{1,3}\.){3}[0-9]{1,3}{2}'");
    
    exec("/sbin/iw dev $target station dump |grep Stat | cut -f 2 -s -d' '", $stations);

    for ($i=0; $i < count($stations); $i++) {
        $output[] = str_replace("Station", "", $stations[$i]);
    }

    exec("ping -b -q -c 2 -s 1472 $broadcast > /dev/null 2>&1");

    if (empty($output)) {
        $list_total[] = array(
            'nombre_dispositivo' => "N.A",
            'mac_address'        => "N.A",
            'ip'  => "N.A",
            'target' => 'N.A',
            'broadcast' => 'N.A'
            );
        echo json_encode($list_total);
        exit();
    }


    foreach ($output as $mac) {
        $mac= $mac;
        exec("wget http://api.macvendors.com/$mac -O $wget_file > /dev/null 2>&1");
        $vendor = shell_exec("cat $wget_file");
        exec("rm $wget_file");
        $ip = shell_exec("arp -a | grep $mac | cut -f 2 -d' '");

        $retval[] =  $vendor."-".$mac."-".$ip;

    }

    foreach ($retval as $value) {
        $a = explode("-", $value);
        $filter_1 =array_filter($a, "strlen");

        $list_clean = array_values($filter_1);
        $list_total[] = array(
            'nombre_dispositivo' => $list_clean[0],
            'mac_address'        => $list_clean[1],
            'ip'  => $list_clean[2],
            'target' => $target,
            'broadcast' => $broadcast
            );
    }

    echo json_encode($list_total);
}

 ?>