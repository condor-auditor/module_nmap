<?php
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../../system/login_check.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	require_once("../../../config/config.php");
	require_once("../__init__.php");
	require_once("../../../tools/execute/exec.php"); 
	$action = strip_tags(trim(filter_input(INPUT_POST,'accion', FILTER_SANITIZE_STRING)));
	if ($action != '' && $action == "update_software_ok") {
		$external_ip = exec("curl ident.me");
		if ($external_ip != "" ) {
			exec_condor("mkdir $path_condor_update");
			exec_condor("git clone $path_module_dowload $path_condor_update");
			if (file_exists("$path_condor_update")) {
				exec_condor("cp -Rf $path_condor_update/* /usr/share/lighttpd/condor/www/modules/".$module_name);
				exec_condor("rm -Rf $path_condor_update");
				echo "si";
			}else{
				echo "no";
			}
		}else{
			echo "no";
		} 	
	}else{
		echo "no";
	}
}else{
	echo "no";
}
?>